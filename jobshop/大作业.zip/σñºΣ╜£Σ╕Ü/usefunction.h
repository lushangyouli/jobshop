void exchange(int *a,int *b);
int max(int * serialnumber,int documentnumber);
int randomNumber(int n);
extern int documentNumber;
extern int *serialNumber;
