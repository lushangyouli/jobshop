#include <time.h>
void output(int *Chromosome);
extern int documentNumber, machineNumber,sumSerial;
extern int *serialNumber, **machine, **Time;
extern clock_t start,end;

