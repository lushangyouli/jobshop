#ifndef _STRUCT_H_
#define _STRUCT_H_
typedef struct Selected{
	int *chromosome1;
	int *chromosome2;
} selectedChromosome;
extern selecterChromosome;
#endif
