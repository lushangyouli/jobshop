void input();
extern int documentNumber, machineNumber;
extern int **Time, **machine, *serialNumber;
